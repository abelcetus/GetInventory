package com.demo.GetInventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
